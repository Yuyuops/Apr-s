# EXPÉRIMENTAL - fichiers de fabrication du Beagle (STL / 3MF)

**Ces fichiers ne font PAS partie du kit numérique principal et ne sont PAS validés pour une imprimante.**
- **Non ouverts dans Bambu Studio, non tranchés avec un logiciel natif, aucune impression réelle.** Aucune compatibilité Bambu n'est annoncée.
- Validation faite : **numérique seulement** (chaque STL / corps 3MF est un solide étanche de volume positif, 3MF bien formés, tout objet tient dans un plateau de 250 mm, 0 chevauchement ; voir `numeric_validation.log`).
- Les tolérances (jeu 0,10 mm par côté, tenons Ø 4,8 mm, ergots Ø 5,0 mm, logement +0,30 mm) sont des PARAMÈTRES à mesurer avec les pièces de test `assembly_test_tolerance_coupon/` AVANT toute impression de modèle.
- Masse et temps sont des FORMULES (PLA supposé 1,24 g/cm3, 8 mm3/s), pas un tranchage : voir `comparison.json`. Aucun coût n'est calculé.

| Dossier | Contenu |
|---|---|
| `bricks_individual_parts/` | briques/plaques/tuiles rectangulaires paramétriques : 10 547 pièces sur 10 567 couvertes (20 formes non couvertes), 88 plateaux 250 x 250 mm, STL + 3MF |
| `modules_printable/` | modèle découpé en 4 modules imprimables avec ergots d'assemblage (STL + 3MF) |
| `modules_shape_aware/` | variante dont les modules suivent l'enveloppe convexe de la géométrie LDraw réelle + goujon de test |
| `assembly_test_tolerance_coupon/` | 22 pièces de test d'assemblage et de tolérances (à imprimer et mesurer d'abord) |
