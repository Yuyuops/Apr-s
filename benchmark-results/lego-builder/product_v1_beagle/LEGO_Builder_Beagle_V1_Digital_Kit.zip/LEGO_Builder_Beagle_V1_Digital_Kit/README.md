# LEGO Builder - Beagle V1 - Digital Kit

**Version 1.0.0 (technique)** - modèle LEGO du Beagle : **10,567 pièces**, **64 références** (pièce x couleur), **23 formes**, **5 couleurs**, **554 étapes** de construction.
Statut : **validé numériquement, PAS encore construit en vrai, PAS commercialisable** (droits et test réel non établis, voir `LICENSES/LICENSES.md` et `docs/LIMITES_CONNUES.md`).

## Par où commencer
1. Ouvrez `docs/GUIDE_UTILISATEUR.md` (le guide pas à pas).
2. Regardez `renders/` (6 vues haute résolution) et `preview/Beagle_V1_turntable.gif` (tour complet).
3. Préparez vos pièces avec `bom/Beagle_V1_BOM.csv` (ou importez `bom/Beagle_V1_rebrickable_import.csv` dans Rebrickable).
4. Construisez avec `instructions/Beagle_V1_Notice.pdf` (561 pages : 6 pages d'introduction, 554 étapes, 1 page de fin).

## Contenu
| Dossier | Fichiers |
|---|---|
| `model/` | `Beagle_V1.ldr` (modèle complet, SHA-256 `551bde0f77f20c227b4c4fde7f9c286c32139c4c6ac2b458edc0b8cedf31808f`), `Beagle_V1_steps.ldr` (mêmes pièces, ordre de montage avec lignes STEP) |
| `instructions/` | `Beagle_V1_Notice.pdf`, `steps.csv` (une ligne par étape : pièces, quantités, couleurs, couches) |
| `bom/` | nomenclature CSV et JSON, liste des références LDraw, import Rebrickable, pièces rares, contrôle de cohérence |
| `renders/` | face, dos, profils gauche et droit, trois-quarts avant et arrière, dessus (PNG 2400 x 2400) |
| `preview/` | tour complet animé (GIF) |
| `validation/` | rapports de validation numérique du moteur (collisions, connexions, stabilité indicative) |
| `docs/` | guide utilisateur, limites connues, fiche de validation humaine à remplir |
| `LICENSES/` | notices de licences et mentions |
| `MANIFEST.json`, `SHA256SUMS.txt` | version, comptes et empreintes SHA-256 de chaque fichier |

English summary: digital kit for a 10,567-piece LEGO-compatible beagle (LDraw model, PDF instructions with 554 steps, BOM CSV/JSON, renders). Numerically validated only; not physically built; not cleared for commercial sale. Instructions are in French.

*LEGO(R) est une marque du groupe LEGO, qui ne parraine, n'autorise ni ne cautionne ce produit. Les noms de pièces suivent les catalogues publics LDraw et Rebrickable.*
