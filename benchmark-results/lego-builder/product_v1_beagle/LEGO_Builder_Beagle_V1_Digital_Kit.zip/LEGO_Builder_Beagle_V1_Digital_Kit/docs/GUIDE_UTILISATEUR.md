# Guide utilisateur - Beagle V1

## 1. Ce que contient le package
Voir le tableau de `README.md`. Tout est autonome : aucun accès à Internet ni à un dépôt n'est nécessaire pour lire le modèle, la nomenclature et la notice.

## 2. Logiciels nécessaires (tous gratuits)
| Besoin | Logiciel possible |
|---|---|
| Lire la notice et les rapports | un lecteur PDF (Adobe Reader, Aperçu, Firefox...) |
| Voir le modèle en 3D (`.ldr`) | **Studio** (BrickLink, gratuit), **LeoCAD** ou **LDView** (libres). Ces logiciels contiennent ou téléchargent la bibliothèque officielle de pièces LDraw. |
| Ouvrir les nomenclatures (`.csv`) | LibreOffice Calc, Excel ou Numbers |
| Voir les rendus et le GIF | n'importe quel navigateur ou visionneuse d'images |
Remarque : le modèle comporte 10,567 pièces ; l'ouverture dans un logiciel 3D peut prendre un moment sur un ordinateur modeste.

## 3. Visualiser le modèle
- **Rapide** : ouvrez les PNG de `renders/` (6 angles) et `preview/Beagle_V1_turntable.gif`.
- **En 3D** : ouvrez `model/Beagle_V1.ldr` dans Studio/LeoCAD/LDView, puis tournez autour du modèle.
- **Étape par étape sur ordinateur** : ouvrez `model/Beagle_V1_steps.ldr` : les lignes STEP délimitent les 554 étapes dans l'ordre de la notice (Studio et LeoCAD proposent un mode « pas à pas »).

## 4. Utiliser la nomenclature (BOM)
- `bom/Beagle_V1_BOM.csv` : une ligne par pièce et par couleur (64 lignes) avec la quantité, le numéro de pièce, la couleur (nom et numéro), la rareté estimée et la masse théorique. **Total : 10,567 pièces.**
- `bom/Beagle_V1_rebrickable_import.csv` : format « Part, Color, Quantity » (numéros de couleur Rebrickable) à importer dans une liste de pièces Rebrickable.
- `bom/Beagle_V1_ldraw_parts.csv` : références de fichiers LDraw (`.dat`) et numéros de couleur LDraw.
- `bom/Beagle_V1_rare_parts.csv` : les 12 références rares ou peu courantes (30 sets Rebrickable ou moins = rare ; 31 à 100 = peu courante) dont 1 rare : Plate 4 x 6 Dark Orange x945 (21 sets) : **à chercher en premier**. Attention : c'est un indicateur de rareté, **pas une information de stock ni de prix** : aucun prix, aucune disponibilité n'est fournie dans ce kit.
- Aucun fichier BrickLink n'est fourni (les correspondances de numéros de pièces et de couleurs BrickLink ne sont pas dans nos données) ; à partir de la liste Rebrickable, vérifiez les possibilités d'export sur le site.
- `bom/bom_cross_check.json` : contrôle automatique BOM = modèle (mêmes quantités, aucune différence).
Couleurs utilisées (5) : Black (0), White (15), Dark Tan (28), Reddish Brown (70), Dark Orange (484).

## 5. Suivre la notice (`instructions/Beagle_V1_Notice.pdf`)
1. Lisez les pages d'introduction : lecture de la notice, liste des pièces, plan, vues du modèle terminé.
2. Triez vos pièces par couleur puis par numéro.
3. Une page = une étape : l'image montre en couleur les pièces à ajouter (les pièces déjà posées sont pâles) ; la liste donne quantité, nom, numéro et couleur ; la phrase sous l'image indique si les pièces se posent simplement ou s'emboîtent, et dans quel sens.
4. Certaines étapes demandent d'emboîter des pièces **par en dessous** (indiqué « vers le haut ») : soutenez ou retournez le modèle avec précaution.
5. 13 petits détails du visage se construisent à part (« Construire à part »), puis se fixent (« Fixer sur le modèle »).
6. À la fin, comparez avec la page « Le modèle terminé » et vérifiez que vous avez posé 10,567 pièces.
`steps.csv` reprend chaque étape sous forme de tableau (pièces `quantitéxnuméro@couleur LDraw`, couches).

## 6. Limites connues
Voir `docs/LIMITES_CONNUES.md` (à lire avant de commencer) et remplissez `docs/FICHE_VALIDATION_HUMAINE.md` après votre construction.
