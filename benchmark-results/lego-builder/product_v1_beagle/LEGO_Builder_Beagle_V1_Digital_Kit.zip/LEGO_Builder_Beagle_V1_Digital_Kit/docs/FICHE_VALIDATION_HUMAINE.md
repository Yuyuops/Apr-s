# Fiche de validation humaine (à remplir après construction)

Testeur : ____________   Date : ____________   Expérience LEGO : débutant / intermédiaire / expert

| # | Question | Réponse (oui / non / remarque) |
|---|---|---|
| 1 | Le ZIP s'ouvre et les fichiers se comprennent sans aide | |
| 2 | Le guide utilisateur est clair | |
| 3 | Les rendus permettent de reconnaître le modèle fini | |
| 4 | J'ai pu rassembler toutes les pièces de la liste (lesquelles manquent ?) | |
| 5 | Quelles pièces ou couleurs ont été difficiles à trouver ? | |
| 6 | Temps passé à préparer/trier les pièces | |
| 7 | Étapes ambiguës (numéros d'étape + description) | |
| 8 | Étapes impossibles ou pièces qui ne s'emboîtent pas (numéros) | |
| 9 | Étapes où il faut emboîter par en dessous : étaient-elles compréhensibles ? | |
| 10 | Le modèle terminé tient-il à la manipulation normale ? Pièces qui se détachent (où ?) | |
| 11 | Total de pièces posées = 10 567 ? Pièces restantes / manquantes | |
| 12 | Temps total de construction | |
| 13 | Le modèle terminé ressemble aux rendus | |
| 14 | Commentaires libres | |
