# Licences et mentions - Beagle V1 Digital Kit

**Ce kit n'est pas déclaré commercialisable.** Les droits sur le modèle source n'ont pas été établis (voir ci-dessous). Ce texte n'est pas un avis juridique.

| Élément | Origine | Condition connue | Statut |
|---|---|---|---|
| Géométrie des pièces (rendus, noms) | Bibliothèque LDraw (ldraw.org), non copiée dans le kit | CC BY (4.0 selon le verrouillage du projet) : citer LDraw.org | mention fournie |
| Numéros de couleurs, années, nombre de sets par pièce | Base de données Rebrickable (rebrickable.com) | conditions d'usage Rebrickable à vérifier avant diffusion ; mention « Données : Rebrickable.com » | à vérifier |
| Modèle du Beagle (forme, couleurs) | reconstruction 3D par Tencent Hunyuan3D-2mv à partir de 4 images de référence puis conversion en briques | licence communautaire Tencent Hunyuan 3D 2.0 : **ne s'applique pas dans l'Union européenne, le Royaume-Uni et la Corée du Sud** (« unlicensed and unauthorized » hors territoire) ; Tencent ne revendique pas de droits sur les sorties | **BLOQUANT à clarifier (juriste)** |
| Images de référence du Beagle | fournies au projet (rendus de LEGO selon `CONTROLE_COHERENCE`), origine et droits non documentés | inconnu | **non établi** |
| Marque LEGO(R) | groupe LEGO | ne parraine ni n'autorise ce produit ; usage du mot LEGO dans un nom commercial à examiner | à examiner |
| Notice PDF, BOM, documents | génération par les outils du projet (Python, ReportLab, Pillow) | licence du dépôt non déclarée | à décider |
